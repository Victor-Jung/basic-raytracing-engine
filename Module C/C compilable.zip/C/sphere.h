#pragma once
#include "structure.h"

void* doesCollideSphere(sParam param);
sPlanEqua makeTangentPlanFromSphere(sPos collisionPoint, sPos centerOfSphere);